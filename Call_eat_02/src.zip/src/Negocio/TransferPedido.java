package Negocio;

public class TransferPedido {

}
