package Integracion;

import com.fasterxml.jackson.databind.ObjectMapper;

public class DAOPedidoImp {
	private static final String FILE_PATH = "pedidos.json";
    private ObjectMapper objectMapper = new ObjectMapper();
}
