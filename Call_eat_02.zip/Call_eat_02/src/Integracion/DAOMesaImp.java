package Integracion;

import com.fasterxml.jackson.databind.ObjectMapper;

public class DAOMesaImp {
	private static final String FILE_PATH = "mesa.json";
    private ObjectMapper objectMapper = new ObjectMapper();
}
