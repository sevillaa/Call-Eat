package Integracion;

import com.fasterxml.jackson.databind.ObjectMapper;


public class DAOPlatoImp {
	
	private static final String FILE_PATH = "platos.json";
    private ObjectMapper objectMapper = new ObjectMapper();
    
   

}
