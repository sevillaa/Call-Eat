package Integracion;

import Negocio.TransferEmpleado;

public class FachadaDAOEmpleadoImp implements FachadaDAOEmpleado {

    private SADAOEmpleado saDaoEmpleado = new SADAOEmpleadoImp();

    @Override
    public TransferEmpleado buscarEmpleado(String correo) {
        return saDaoEmpleado.buscarEmpleado(correo);
    }

    @Override
    public boolean registrarEmpleado(TransferEmpleado empleado) {
        return saDaoEmpleado.registrarEmpleado(empleado);
    }

    @Override
    public boolean eliminarEmpleado(TransferEmpleado empleado) {
        return saDaoEmpleado.eliminarEmpleado(empleado);
    }
    

	
}
