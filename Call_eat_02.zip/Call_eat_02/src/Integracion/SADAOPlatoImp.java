package Integracion;

import Negocio.TransferPlato;

public class SADAOPlatoImp implements SADAOPlato {
	
	DAOPlatoImp dao = new DAOPlatoImp();

	@Override
	public boolean crearPlato(TransferPlato plato) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean eliminarPlato(TransferPlato plato) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public TransferPlato buscarPlato(String idPlato) {
		// TODO Auto-generated method stub
		return null;
	}

}
