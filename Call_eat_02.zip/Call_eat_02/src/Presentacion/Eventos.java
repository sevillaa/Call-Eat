package Presentacion;

public class Eventos {

	final static public int ADD_CLIENTE = 1;
	public static final int INICIAR_SESION = 2;
	public static final int CLIENTE_REGISTRADO = 3;
	public static final int PEDIDOS_ACTUALIZADOS = 4;
	
}
