package Negocio;

public class TransferMesa {

}
